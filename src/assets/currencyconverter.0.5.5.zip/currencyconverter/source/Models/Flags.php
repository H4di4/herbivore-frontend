<?php
namespace Korobochkin\CurrencyConverter\Models;

class Flags {

	public $sizes = array(
		16,
		24,
		32,
		48,
		64
	);
}